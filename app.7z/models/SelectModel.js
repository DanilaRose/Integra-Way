class SelectModel {
   constructor(Id, Name, Selected, Disabled) {
      this.Id = Id,
      this.Name = Name,
      this.Selected = Selected,
      this.Disabled = Disabled
   }
}